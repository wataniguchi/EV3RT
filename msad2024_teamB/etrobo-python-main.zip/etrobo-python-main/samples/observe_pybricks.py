#!/usr/bin/env pybricks-micropython
from observe_simulator import run

if __name__ == '__main__':
    run(backend='pybricks')
